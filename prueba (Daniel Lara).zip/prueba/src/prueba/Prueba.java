/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import com.sun.xml.internal.bind.v2.runtime.RuntimeUtil;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author danny
 */
public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Aqui se invoca
        selectivas();
    }
    
    //Signatura es la manera en que se declarar las clases
    
    public static void consola() {
        int num;
        System.out.println("Digite un número para la consola");
        Scanner escanercito = new Scanner(System.in);
        num = escanercito.nextInt();
        
        System.out.println("La variable es = " + num);
    }
    
    public static void pantalla(){
        int a;
        a = Integer.parseInt(JOptionPane.showInputDialog(null,"Escriba un número"));
        //JOptionPane se usa para mostrar en pantalla
        JOptionPane.showMessageDialog(null, "La variable ingresada es = "+a);
    } 
    
    public static void conversores() {
        String cadena = "Cosmico";
        int num1 = 10;
        double num2 = 5.2;
        //  =(int) Esto es un casteo para convertir datos
        num1 =(int) num2;
        System.out.println(num1);
        //Metodo String.ValueOf se usa para pasar una cadena a un entero
        cadena = String.valueOf(num1);
        System.out.println(cadena);
        //Metodo Integer.toString se usa para pasar una cadena a un entero
        cadena = Integer.toString(num1);
        System.out.println(cadena);
    }
    
    public static void pruebaFor() {
        for (int i = 0; i < 10; i=i+2) {
            //System.out.println("Repetición " + i);
            /*
            if (i == 4) {
                System.out.println(i);
                break;
            } else {
                System.out.println(i);
            }
            */
            if (i == 4) {
                continue;
            } 
            System.out.println(i);
        }
    }
    
    public static void selectivas() {
        int a = 0;
        String b = "Siga";
        if (a == 0 & b.equalsIgnoreCase("Siga")) {
            System.out.println("Verdadero");
        } else {
            System.out.println("Falso");
        }
    }
    
    public static void repetitivas() {
        for (int i = 0; i < 10; i += 3) {
            
        }
    }
}